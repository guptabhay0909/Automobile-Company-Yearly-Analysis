package Capsule_Corp;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author win10
 */
public class Graph extends javax.swing.JFrame {
    Connection con;
    Statement stm;
    ResultSet rs;
    String query;

    /**
     * Creates new form Graph
     */
    public Graph(String year1,String year2)
    {
        initComponents();
        String series1="Units of "+year1;
        String series2="Money of "+year1;
        DefaultCategoryDataset  dataset=new DefaultCategoryDataset();
        try{
        Class.forName("java.sql.Driver");
        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/capsule_corp","root","tiger");
        stm=con.createStatement();
        query="SELECT SUM( Unit ) , MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year1+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        rs=stm.executeQuery(query);
        double n;
        while(rs.next())
        {
            n=rs.getLong(1);
            dataset.addValue(n,series1,rs.getString(2));
        }
        query="SELECT SUM( Revenue_Coll ), MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year1+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        rs=stm.executeQuery(query);
        while(rs.next())
        {
            n=rs.getDouble(1);
            
            dataset.addValue(n,series2,rs.getString(2));
        }
        
        String series3="Units Of "+year2;
        String series4="Money Of "+year2;
        query="SELECT SUM( Unit ) , MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year2+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        rs=stm.executeQuery(query);
        while(rs.next())
        {
            n=rs.getLong(1);
            dataset.addValue(n,series3,rs.getString(2));
        }
        query="SELECT SUM( Revenue_Coll ), MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year2+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        rs=stm.executeQuery(query);
        while(rs.next())
        {
            n=rs.getDouble(1);
            
            dataset.addValue(n,series4,rs.getString(2));
        }
        JFreeChart chart1=ChartFactory.createLineChart("Analysis","Months","Units & Money", dataset);
        ChartPanel panel=new ChartPanel(chart1);
        panel.setSize(400, 600);
        panel.setMouseWheelEnabled(true);
        setContentPane(panel);
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public Graph(String year){
        initComponents();
        String series1="Units";// String series = "Number of Books Sold";
        String series2="Money";
        DefaultCategoryDataset  dataset=new DefaultCategoryDataset();
        try{
        Class.forName("java.sql.Driver");
        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/capsule_corp","root","tiger");
        stm=con.createStatement();
        query="SELECT SUM( Unit ) , MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        //query = "Select bookids, quantityofeachbook from billfirssthnd";
        /*
            
            query execute.
        HashMap <Integer,Integer> map = new HashMap<>();
            while(rs.next())
        {
            String [] arr = rs.getString(1).split(", ");
            String [] arr2 = rs.getString(2).split(", ");
            for(int i = 0;i<arr.length;i++)
        {
               int x = Integer.parseInt(arr[i]);
               int y = Integer.parseInt(arr2[i]);
               if(map.containsKey(x))
        {
                int j = map.get(x);
                map.replace(x,j,j+y);
        }
        else
        {
                map.put(x,y);
        }
                       }
        }
        hashmap sort by value java t point se hi nikalna hai. fir hashmap ko first 5 times iterate krke bar graph.
        aab query banani hai un ids ko leke
        aur books ka naam lana hai
        aur vo ids
        phir while rs.next mein
        un ids ko use krke unki value le aayenge aur graph form kr denge.
        */
        rs=stm.executeQuery(query);
        double n;
        while(rs.next())
        {
            n=rs.getLong(1);
            dataset.addValue(n,series1,rs.getString(2));
        }
        
        query="SELECT SUM( Revenue_Coll ), MONTHNAME( Record_Date ) FROM dataset WHERE YEAR( Record_Date ) ='"+year+"' GROUP BY MONTHNAME( Record_Date ) Order by MONTH( Record_Date ) asc;";
        rs=stm.executeQuery(query);
        while(rs.next())
        {
            n=rs.getDouble(1);
            
            dataset.addValue(n,series2,rs.getString(2));
        }
        JFreeChart chart1=ChartFactory.createLineChart("Analysis","Months","Units & Money", dataset);
        ChartPanel panel=new ChartPanel(chart1);
        panel.setSize(400, 600);
        panel.setMouseWheelEnabled(true);
        setContentPane(panel);
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    public Graph() {
        initComponents();
        String series1="Units";
        String series2="Money";
        DefaultCategoryDataset  dataset=new DefaultCategoryDataset();
        //DefaultCategoryDataset  dataset1=new DefaultCategoryDataset();
        try{
        Class.forName("java.sql.Driver");
        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/capsule_corp","root","tiger");
        stm=con.createStatement();
        query="Select SUM(Unit) , YEAR(Record_Date) from dataset group by Year(Record_Date);";
        rs=stm.executeQuery(query);
        double n;
        while(rs.next())
        {
            n=rs.getLong(1);
            dataset.addValue(n,series1,rs.getString(2));
        }
        query="Select SUM(Revenue_Coll) , YEAR(Record_Date) from dataset group by Year(Record_Date);";
        rs=stm.executeQuery(query);
        /*JFreeChart chart1=ChartFactory.createLineChart("Analysis","Year","Units", dataset);
        ChartPanel panel=new ChartPanel(chart1);
        panel.setSize(400, 600);
        panel.setMouseWheelEnabled(true);
        setContentPane(panel);*/
        while(rs.next())
        {
            n=rs.getDouble(1);
            //dataset1.addValue(n,series2,rs.getString(2));
            dataset.addValue(n,series2,rs.getString(2));
        }
        JFreeChart chart1=ChartFactory.createLineChart("Analysis","Year","Units & Money", dataset);
        ChartPanel panel=new ChartPanel(chart1);
        panel.setSize(400, 600);
        panel.setMouseWheelEnabled(true);
        setContentPane(panel);
        /*JFreeChart chart=ChartFactory.createLineChart("Analysis","Year","Money", dataset1);
        ChartPanel panel1=new ChartPanel(chart);
        panel1.setSize(400, 600);
        panel1.setMouseWheelEnabled(true);
        setContentPane(panel1);*/
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1060, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 682, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Graph.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Graph.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Graph.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Graph.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Graph().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
